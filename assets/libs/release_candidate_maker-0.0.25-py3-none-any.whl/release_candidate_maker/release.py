#!/usr/bin/env python3

import re
import glob
import os
import shutil
import subprocess
import traceback
import sys
from pathlib import Path
from release_candidate_maker.version_handler import VersionHandler



#####################################

class ReleaseMaker:
    ROOT = None

    def __init__(self, *,
        new_version_handlers:list[VersionHandler]=None,
        copy_to_paths:list[str]=None
    ) -> None:
        self.ROOT = Path(os.getcwd()).resolve()
        self.new_version_handlers:list[VersionHandler] = [] if new_version_handlers is None else new_version_handlers
        self.copy_to_paths = None if copy_to_paths is None else copy_to_paths
        print(str(self))

    def __str__(self) -> str:

        return f"ReleaseMaker: {self.new_version_handlers}, {self.copy_to_paths}"

    def read_pyproject(self) -> str:
        """Read pyproject.toml file."""
        pyproject_path = Path("./pyproject.toml")
        if not pyproject_path.exists():
            print("Error: pyproject.toml not found in current directory")
            sys.exit(1)
        with open(pyproject_path, 'r') as f:
            content = f.read()
        return content


    def extract_version(self, content:str) -> str:
        """Extract version number from pyproject.toml content."""
        match = re.search(r'^version\s*=\s*["\']([^"\']+)["\']', content, re.MULTILINE)
        if not match:
            print("Error: Could not find version in pyproject.toml")
            sys.exit(1)
        return match.group(1)


    def increment_version(self, version:str) -> str:
        """Increment the patch version (third number)."""
        parts = version.split('.')
        if len(parts) != 3:
            print(f"Error: Version format not supported: {version}")
            sys.exit(1)
        try:
            parts[2] = str(int(parts[2]) + 1)
        except ValueError:
            print(f"Error: Cannot increment non-numeric patch version: {parts[2]}")
            sys.exit(1)
        return '.'.join(parts)


    def update_version_in_content(self, content:str, old_version:str, new_version:str) -> str:
        """Update version in pyproject.toml content."""
        pattern = re.compile(r'^(version\s*=\s*["\'])' + re.escape(old_version) + r'(["\'])', re.MULTILINE)
        new_content = pattern.sub(r'\g<1>' + new_version + r'\g<2>', content)
        return new_content


    def save_pyproject(self, content:str) -> None:
        """Save updated pyproject.toml."""
        with open("./pyproject.toml", 'w') as f:
            f.write(content)


    def get_yes_no_input(self, prompt:str) -> bool:
        """Get yes/no input from user."""
        while True:
            response = input(f"{prompt} (y/n): ").lower()
            if response and response.strip().lower() in ['y', 'yes']:
                return True
            elif response and response.strip().lower() in ['n', 'no']:
                return False
            else:
                print("Please enter 'y' or 'n'")


    def update_version_if(self) -> None:
        content = self.read_pyproject()
        current_version = self.extract_version(content)
        print(f"\nCurrent version: {current_version}")
        new_version = self.increment_version(current_version)
        if self.get_yes_no_input(f"Do you want to update the version to {new_version}?"):
            print(f"New version will be: {new_version}")
            content = self.update_version_in_content(content, current_version, new_version)
            self.save_pyproject(content)
            print(f"Updated pyproject.toml to version {new_version}")
            #
            # write version into storage/dev/version.txt
            #
            if self.new_version_handlers:
                for _ in self.new_version_handlers:
                    try:
                        _.handle_new(current_version, new_version)
                    except:
                        print(traceback.format_exc())
            """
            with open( os.path.join("storage", "dev", "version.txt"), "w") as file:
                file.write(new_version)
            """
            self.create_git_tag_if(new_version)

        else:
            new_version = current_version
            print(f"Keeping current version: {current_version}")

    def create_git_tag_if(self, version:str) -> None:
        if self.get_yes_no_input(f"Do you want to tag version {version} in git?"):
            self.create_git_tag(version)

    def create_git_tag(self, version:str) -> None:
        """Create a git tag for the release."""
        tag_name = f"v{version}"

        # Check if tag already exists
        result = subprocess.run(['git', 'tag', '-l', tag_name], capture_output=True, text=True)
        if result.stdout.strip():
            print(f"Warning: Tag '{tag_name}' already exists. Stopping so you can attend to it.")
            return
            """
            response = input("Do you want to delete and recreate it? (y/n): ").lower()
            if response == 'y':
                subprocess.run(['git', 'tag', '-d', tag_name], check=True)
            else:
                return
            """

        # Create the tag
        result = subprocess.run(['git', 'tag', '-a', tag_name, '-m', f'Release version {version}'],
                              capture_output=True, text=True)

        if result.returncode != 0:
            print(f"Error creating git tag: {result.stderr}")
            sys.exit(1)

        print(f"Created git tag: {tag_name}")

        print(f"Pushing git tag to origin: {tag_name}")

        result = subprocess.run(['git', 'push', 'origin', tag_name],
                              capture_output=True, text=True)

        if result.returncode != 0:
            print(f"Error pushing tag: {result.stderr}")
            sys.exit(1)



    #####################################


    def run(self, cmd: list[str]) -> None:
        """Run a subprocess command, exit on failure."""
        print(f"  $ {' '.join(cmd)}")
        result = subprocess.run(cmd, cwd=self.ROOT)
        if result.returncode != 0:
            print(f"\n[ERROR] Command failed with exit code {result.returncode}: {' '.join(cmd)}")
            sys.exit(result.returncode)


    def remove_files(self, pattern: str, base: Path, description: str) -> None:
        """Glob-remove files matching pattern under base, with a status line."""
        matches = list(base.glob(pattern))
        if matches:
            for f in matches:
                f.unlink()
            print(f"  removed {len(matches)} {description}")
        else:
            print(f"  (no {description} found)")


    def clear_pyc_files(self) -> None:
        print("\n--- Clearing .pyc files ---")
        matches = list(self.ROOT.rglob("*.pyc"))
        for f in matches:
            f.unlink()
        print(f"  removed {len(matches)} .pyc file(s)")


    def clear_logs(self) -> None:
        print("\n--- Clearing ./logs ---")
        logs_dir = self.ROOT / "logs"
        if not logs_dir.is_dir():
            print("  [WARN] ./logs directory not found, skipping")
            return
        remove_files("*.log*", logs_dir, ".log file(s)")
        ds = logs_dir / ".DS_Store"
        if ds.exists():
            ds.unlink()
            print("  removed .DS_Store")
        print("  logs dir now contains:", [f.name for f in sorted(logs_dir.iterdir())] or "(empty)")


    def clear_dist(self) -> None:
        print("\n--- Clearing ./dist ---")
        dist_dir = self.ROOT / "dist"
        if not dist_dir.is_dir():
            print("  ./dist not found, will be created by build")
            return
        removed = 0
        for f in dist_dir.iterdir():
            if f.is_file():
                f.unlink()
                removed += 1
        print(f"  removed {removed} file(s) from ./dist")


    def build(self) -> None:
        print("\n--- Building dist ---")
        self.run(["poetry", "sync"])
        self.run(["poetry", "build"])


    def copy_artifacts(self) -> None:
        print("\n--- Copying artifacts ---")
        dist_dir = self.ROOT / "dist"
        builds_dir = self.ROOT / "builds"
        builds_dir.mkdir(exist_ok=True)

        flightpath_assets = Path.home() / "dev" / "flightpath" / "assets"



        dests = [
            ("*.whl",   [builds_dir],                          ".whl → builds/"),
            ("*.tar.gz", [builds_dir, flightpath_assets],      ".tar.gz → builds/ and flightpath assets/"),
        ]
        if self.copy_to_paths is not None:
            for _ in self.copy_to_paths:
                dests.append(
                    ("*.whl",  [Path(_)],  f".whl → {_}")
                )

        for pattern, destinations, label in dests:
            files = list(dist_dir.glob(pattern))
            if not files:
                print(f"  [WARN] no {pattern} found in {dist_dir}")
                continue
            for src in files:
                for dest in destinations:
                    if not dest.is_dir():
                        print(f"  [WARN] destination not found, skipping: {dest}")
                        continue
                    shutil.copy2(src, dest / src.name)
                print(f"  {src.name}  →  {label}")


    def main(self) -> None:
        print(f"Working directory: {self.ROOT}")
        self.clear_pyc_files()
        self.clear_logs()
        self.clear_dist()
        self.update_version_if()
        self.build()
        self.copy_artifacts()
        print("\n--- Done ---")

def run():
    maker = ReleaseMaker()
    maker.main()

if __name__ == "__main__":
    run()
