from abc import ABC, abstractmethod

class VersionHandler(ABC):

    @abstractmethod
    def handle_new(self, old_version:str, new_version:str) -> None:
        ...

class NoopVersionHandler(VersionHandler):

    def handle_new(self, old_version:str, new_version:str) -> None:
        print(f"NoopVersionHandler!  {old_version} -> {new_version}")

